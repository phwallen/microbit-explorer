//#-hidden-code
//
//  Contents.swift
//
import Foundation
start()
DispatchQueue.global(qos: .background).async {
//#-end-hidden-code
/*:#localized(key: "ExplorerNarative")
To use the Explorer playground book make sure your micro:bit is flashed with the **Explorer Program**. *For more details see:* [Flash the micro:bit with the explorer program](https://phwallen.github.io/microbit-explorer/#flash-the-microbit-with-the-explorer-program)
 Connect your micro:bit to a suitable power supply and check that **R** is displayed on the LED matrix.
 
 */
    //#-editable-code
    clear()
    let source = """
    mov r1,#255    ;define counter
    lsl r1,r1,#1   ;multiple by 2
    loop:
    sub r1,#1      ;decrement the counter
    bne loop
    """
    let machine_code = assemble(source)
    execute(machine_code)
    //#-end-editable-code

//#-hidden-code
   finish()
}
//#-end-hidden-code
