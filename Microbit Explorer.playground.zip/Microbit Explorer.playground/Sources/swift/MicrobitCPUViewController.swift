//
//  MicrobitCPUViewController.swift
//
//
//  Created by Peter Wallen on 01/05/2018.
//  Copyright © 2018 Peter Wallen. All rights reserved.
//

import UIKit

public class MicrobitCPUViewController: UIViewController {
    
    var keyPadView:KeyPadView?
    var controlButtonsView:ControlButtonsView?
    var processorView:ProcessorView?
    #if canImport(PlaygroundBluetooth)
        var playgroundMicrobitConnection:PlaygroundMicrobitConnectionView?
        var microbit:PlaygroundMicrobit?
    #else
        var microbit:Microbit?
    #endif
    public var microbitCPU:MicrobitCPU?
    //var microbit = PlaygroundMicrobit()
    
    public override func viewDidLoad() {
        super.viewDidLoad()
        keyPadView = KeyPadView(view)
        keyPadView?.delegate = self
        processorView = ProcessorView(view)
        #if canImport(PlaygroundBluetooth)
             playgroundMicrobitConnection = PlaygroundMicrobitConnectionView(view:view,microbit:microbitCPU!.microbit!)
        #else
            controlButtonsView = ControlButtonsView(view)
            controlButtonsView?.delegate = self
        #endif
        //microbitCPU = MicrobitCPU()
        microbitCPU?.delegate = self
    }
    public override func viewDidLayoutSubviews() {
        
        let width = view.bounds.size.width
        //let height = view.bounds.size.height
        //print ("width = \(width) height = \(height)")
        keyPadView?.changeLayout(view,width:width)
    }
}
extension MicrobitCPUViewController:MicrobitCPUViewsDelegate {
    
    func controlButtonPressed(_ key: String) {
        switch key {
        case "Connect" :
            microbitCPU?.connect()
        case "Disconnect" :
            microbitCPU?.disconnect()
        case "Release" :
            microbitCPU?.command(parm: 0x01)
        case "Reset" :
            microbitCPU?.command(parm:0x02)
        case "Clear" :
           microbitCPU?.command(parm: 0x03)
        default :
            print ("Invalid control key pressed")
        }
    }
    func execute(instructionBuffer: String) {
        microbitCPU?.process(instructionBuffer: instructionBuffer)
    }
    func store(storageBuffer: String) {
        microbitCPU?.store(storageBuffer: storageBuffer)
    }
}
extension MicrobitCPUViewController:MicrobitCPUDelegate {
    public func didUpdateRegisters() {
        processorView?.registerView?.setPSR(value: (microbitCPU?.psr)!)
        for register in 0 ... 7 {
            processorView?.registerView?.set(register: register, value: (microbitCPU?.registers[register])!)
        }
    }
    public func didUpdateMemory() {
        processorView?.memoryView?.update(memory: (microbitCPU?.memory)!)
    }
    
    public func didConnect() {
        NSLog("Did Connect")
        microbitCPU?.clear()
    }
    public func didFetchInstruction(instructionBuffer: String) {
        processorView?.message(" ")
        processorView?.instruction(instructionBuffer)
    }
    public func show(message:String) {
        processorView?.message(message)
    }
    public func keyPad(message:String) {
        keyPadView?.messageLabel.text = message
    }

}
