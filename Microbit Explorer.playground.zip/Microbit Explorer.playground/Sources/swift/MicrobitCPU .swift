//
//  MicrobitCPU.swift
//  MicrobitCPU1
//
//  Created by Peter Wallen on 21/06/2018.
//  Copyright © 2018 Peter Wallen. All rights reserved.
//
//  The MicrobitCPU class represents the Nordic nRF51822 processor on the Micro:bit.
//  Physical connection with the Micro:bit is established over Bluetooth using the Microbit class.
import Foundation

public protocol MicrobitCPUDelegate {
    func didUpdateRegisters()
    func didUpdateMemory()
    func didConnect()
    func didFetchInstruction(instructionBuffer:String)
    func show(message:String)
    func keyPad(message:String)
}

public class MicrobitCPU {
    
    struct RegisterData {
        let word1:Int32
        let word2:Int32
        let word3:Int32
        let word4:Int32
        let word5:Int32
    }
    #if canImport(PlaygroundBluetooth)
        var microbit:PlaygroundMicrobit?
    #else
        var microbit:Microbit?
    #endif
    
    public var deviceID = "BBC micro:bit"
    
    public var delegate:MicrobitCPUDelegate?
    
    var psr:UInt32 = 0
    var registers:[Int32] = Array(repeating: 0, count: 8)
    var memory:[Int32] = Array(repeating: 0,count: 4)
    
    var connected = false
    var inProgress = false
    
    var programCounter = 0
    var linkRegister = 0
    
    public init() {
        #if canImport(PlaygroundBluetooth)
            microbit = PlaygroundMicrobit()
        #else
            microbit = Microbit("BBC micro:bit [zuvev]")
        #endif
        microbit?.delegate = self
    }
   
    // connect the physical Micro:bit
    func connect() {
         #if !canImport(PlaygroundBluetooth)
            microbit?.startScanning()
        #endif
    }
    // disconnect the physical Micro:bit
    func disconnect() {
        //microbit?.disconnect()
    }
    // send a command to the micro:bit using the UART Bluettoth service
    func command(parm:UInt8) {
        var command:[UInt8] = Array(repeating: 0, count: 20)
        command[19] = parm
        print("\(Data(command).map { String(format: "%02x", $0 ) }.joined())")
        microbit?.uartSend(buffer: Data(command))
    }
    func store(storageBuffer:String) {
        var storageData:Data = Data()
        let trimmedInstruction = storageBuffer.components(separatedBy: .whitespaces).joined()
        if trimmedInstruction.count > 0  && trimmedInstruction.count <= 8 {
            let number = UInt32(trimmedInstruction,radix:16)
            storageData.append(contentsOf:toData32(number!))
        } else {
            delegate?.keyPad(message: "Invalid Value")
            return
        }
        if storageData.count < 20 {
            for _ in 0 ..< 20 - storageData.count {
                storageData.append(0x00)
            }
        }
        storageData[19] = UInt8(0x04)
        microbit?.uartSend(buffer: Data(storageData))
        NSLog("\(storageData.map { String(format: "%02x", $0 ) }.joined())")
    }
    func clear() {
        inProgress = true
        command(parm: 0x03)
    }
    func process(instructionBuffer:String) {
        delegate?.didFetchInstruction(instructionBuffer: instructionBuffer)
        var instructionData:Data = Data()
        let characters = Array(instructionBuffer)
        for i in stride(from: 0, to: characters.count, by: 4) {
            var charHex:[Character] = Array()
            charHex.append(characters[i])
            charHex.append(characters[i+1])
            charHex.append(characters[i+2])
            charHex.append(characters[i+3])
            let hex = String(charHex)
            instructionData.append(contentsOf:toData16(UInt16(hex,radix:16)!))
        }
        transmit(buffer: instructionData)
    }
    func process(instruction:UInt16) {
        var instructionData:Data = Data()
        instructionData.append(contentsOf:toData16(instruction))
        if interpret(instruction: instruction) == 0 {
            transmit(buffer: instructionData)
        }
    }
    func toData16(_ value: UInt16) -> Data {
        var value = value
        return withUnsafeBytes(of: &value) { Data($0) }
    }
    func toData32(_ value: UInt32) -> Data {
        var value = value
        return withUnsafeBytes(of: &value) { Data($0) }
    }
    func transmit(buffer:Data) {
        var instructionData = Data(buffer)
        instructionData.append(contentsOf: [0x70,0x47])
        if instructionData.count < 20 {
            for _ in 0 ..< 20 - instructionData.count {
                instructionData.append(0x00)
            }
        }
        print("\(instructionData.map { String(format: "%02x", $0 ) }.joined())")
        microbit?.uartSend(buffer: Data(instructionData))
    }
    func receive(message:Data) {
        NSLog("\(message.map { String(format: "%02x", $0 ) }.joined())")
        let registerData = decode(data: message)
        switch (registerData.word5) {
        case 4 :
            memory[0] = registerData.word1
            memory[1] = registerData.word2
            memory[2] = registerData.word3
            memory[3] = registerData.word4
            delegate?.didUpdateMemory()
            inProgress = false
        case 1:
            registers[0] = registerData.word1
            registers[1] = registerData.word2
            registers[2] = registerData.word3
            registers[3] = registerData.word4
        default:
            registers[4] = registerData.word1
            registers[5] = registerData.word2
            registers[6] = registerData.word3
            registers[7] = registerData.word4
            psr = UInt32(bitPattern:registerData.word5)
            delegate?.didUpdateRegisters()
        }
    }
    func decode(data:Data) -> RegisterData {
        let registerData = data.withUnsafeBytes {
            (pointer: UnsafePointer<Int32>) -> RegisterData in
            RegisterData(word1:pointer[0],
                         word2:pointer[1],
                         word3:pointer[2],
                         word4:pointer[3],
                         word5:pointer[4])
        }
        return registerData
    }
    public func execute(program:[UInt16],interval:Double = 1.0) {
        let timer = Timer(timeInterval: interval, repeats: true, block: {(timer)
            in
            if (self.connected && !self.inProgress) {
                if self.programCounter < program.count {
                    self.inProgress = true
                    let instructionText = String(format:"%04X",program[self.programCounter])
                    self.delegate?.didFetchInstruction(instructionBuffer: instructionText)
                    self.process(instruction: program[self.programCounter])
                } else {
                    timer.invalidate()
                }
            }
        })
        RunLoop.current.add(timer, forMode: .defaultRunLoopMode)
    }
    public func execute(program:String,interval:Double = 1.0) {
        let trimmedInstructionBuffer = program.components(separatedBy: .whitespaces).joined()
        if ((trimmedInstructionBuffer.count) % 4) != 0 {
            delegate?.show(message:"Incomplete instruction")
        } else {
            let characters = Array(trimmedInstructionBuffer)
            var programBuffer:[UInt16] = Array()
            for i in stride(from: 0, to: characters.count, by: 4) {
                var charHex:[Character] = Array()
                charHex.append(characters[i])
                charHex.append(characters[i+1])
                charHex.append(characters[i+2])
                charHex.append(characters[i+3])
                let hex = String(charHex)
                if let instruction = UInt16(hex,radix:16) {
                    programBuffer.append(instruction)
                } else {
                    delegate?.show(message:"Invalid Instruction")
                    return
                }
            }
            execute(program: programBuffer,interval:interval)
        }
    }
    func message(format:Int,description:String) {
        delegate?.show(message: "\(format) \(programCounter) \(description)")
    }
    func interpret(instruction:UInt16)->Int {
        var instructionFormat = 0
        let formats:[[UInt16]] = [
            [19,0xf000,0xf000],
            [18,0xf800,0xe000],
            [17,0xff00,0xdf00],
            [16,0xf000,0xd000],
            [15,0xf000,0xc000],
            [14,0xf600,0xb400],
            [13,0xff00,0xb000],
            [12,0xf000,0xa000],
            [11,0xf000,0x9000],
            [10,0xf000,0x8000],
            [09,0xe000,0x6000],
            [08,0xf200,0x5200],
            [07,0xf200,0x5000],
            [06,0xf800,0x4800],
            [05,0xfc00,0x4400],
            [04,0xfc00,0x4000],
            [03,0xe000,0x2000],
            [02,0xf800,0x1800],
            [01,0xe000,0x0000]
        ]
        for format in formats {
            if (instruction & format[1] ) == format[2] {
                instructionFormat = Int(format[0])
                break
            }
        }
        switch instructionFormat {
        case 5 :
            let op = (instruction & 0x0300) >> 8
            let rs = (instruction & 0x0038) >> 3
            let h2 = (instruction & 0x0040) >> 6
            if op == 3 {
                inProgress = false
                if h2 == 1 {
                    programCounter = linkRegister
                    message(format: instructionFormat, description: "Branch on Link Register")
                } else {
                    programCounter = Int(registers[Int(rs)])
                    message(format: instructionFormat, description: "Branch on Register \(rs)")
                }
            }
            return 5
        case 16 :
            let cc = (instruction & 0x0f00) >> 8
            let offset = UInt8(instruction & 0x00ff)
            let signedOffset = Int8(bitPattern: offset)
            
            let psrV = (psr & 0x10000000 != 0)  // V
            let psrC = (psr & 0x20000000 != 0)  // C
            let psrZ = (psr & 0x40000000 != 0)  // Z
            let psrN = (psr & 0x80000000 != 0)  // N
            
            programCounter += 1
            
            inProgress = false
            
            switch cc {
            case 0 :
                if psrZ {
                    programCounter = (programCounter + 1) + Int(signedOffset)
                    message(format: instructionFormat, description: "BEQ")
                }
            case 1 :
                if !psrZ {
                    programCounter = (programCounter + 1) + Int(signedOffset)
                    message(format: instructionFormat, description: "BNE")
                }
            case 2 :
                if psrC {
                    programCounter = (programCounter + 1) + Int(signedOffset)
                    message(format: instructionFormat, description: "BCS")
                }
            case 3 :
                if !psrC {
                    programCounter = (programCounter + 1) + Int(signedOffset)
                    message(format: instructionFormat, description: "BCC")
                }
            case 4 :
                if psrN {
                    programCounter = (programCounter + 1) + Int(signedOffset)
                    message(format: instructionFormat, description: "BMI")
                }
            case 5 :
                if !psrN {
                    programCounter = (programCounter + 1) + Int(signedOffset)
                    message(format: instructionFormat, description: "BPL")
                }
            case 6 :
                if psrV {
                    programCounter = (programCounter + 1) + Int(signedOffset)
                    message(format: instructionFormat, description: "BVS")
                }
            case 7 :
                if !psrV {
                    programCounter = (programCounter + 1) + Int(signedOffset)
                    message(format: instructionFormat, description: "BVC")
                }
            case 8 :
                if (psrC && !psrZ) {
                    programCounter = (programCounter + 1) + Int(signedOffset)
                    message(format: instructionFormat, description: "BHI")
                }
            case 9 :
                if (!psrC || psrZ) {
                    programCounter = (programCounter + 1) + Int(signedOffset)
                    message(format: instructionFormat, description: "BLS")
                }
            case 10 :
                if (psrN && psrV) || (!psrN && !psrV) {
                    programCounter = (programCounter + 1) + Int(signedOffset)
                    message(format: instructionFormat, description: "BGE")
                }
            case 11 :
                if (psrN && !psrV) || (!psrN && psrV) {
                    programCounter = (programCounter + 1) + Int(signedOffset)
                    message(format: instructionFormat, description: "BLT")
                }
            case 12 :
                if (!psrZ && ((psrN && psrV) || (!psrN && !psrV))) {
                    programCounter = (programCounter  + 1) + Int(signedOffset)
                    message(format: instructionFormat, description: "BGT")
                }
            case 13 :
                if (psrZ || (psrN && !psrV) || (!psrN && psrV)) {
                    programCounter = (programCounter + 1)  + Int(signedOffset)
                    message(format: instructionFormat, description: "BLE")
                }
            default:
                message(format: instructionFormat, description: "Invalid Conditional Branch")
            }
            return 16
        case 17 :
            let comment = UInt8(instruction & 0x00ff)
            message (format:instructionFormat,description: "Software Interupt \(comment)")
            return 17
        case 18 :
            let offset = UInt8(instruction & 0x00ff)
            let signedOffset = Int8(bitPattern: offset)
            programCounter = (programCounter + 2) + Int(signedOffset)
            message (format:instructionFormat,description:"Unconditional Branch")
            inProgress = false
            return 18
        case 19 :
            let type = (instruction & 0x0800) >> 11
            inProgress = false
            if type == 1 {
                let offset = UInt8(instruction & 0x00ff)
                let signedOffset = Int8(bitPattern: offset)
                programCounter = (programCounter + 1) + Int(signedOffset)
            } else {
                linkRegister = programCounter
                programCounter += 1
                message(format: instructionFormat, description:"Long Branch and Link")
            }
            return 19
        default :
            programCounter += 1
            message(format: instructionFormat, description: "Process Instruction")
            return 0
        }
    }
}
extension MicrobitCPU:MicrobitDelegate {
    public func uartReceived(message: Data) {
        receive(message: message)
    }
    public func serviceAvailable(service:ServiceName) {
        if service == .UART {
            let timer = Timer(timeInterval: 0.1, repeats: false, block: {(timer)
                in
                self.connected = true
                self.delegate?.didConnect()
            })
            RunLoop.current.add(timer, forMode: .defaultRunLoopMode)
        }
    }
}
