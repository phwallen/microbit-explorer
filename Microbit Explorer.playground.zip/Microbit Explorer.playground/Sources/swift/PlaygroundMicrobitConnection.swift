import UIKit
import PlaygroundBluetooth

//public let microbit = PlaygroundMicrobit()
//public let microbitConnectionView = PlaygroundBluetoothConnectionView(centralManager:microbit.centralManager!)


public class PlaygroundMicrobitConnectionView {
    
    public init(view:UIView,microbit:PlaygroundMicrobit) {
        let connectionView = PlaygroundBluetoothConnectionView(centralManager:microbit.centralManager!)
        connectionView.delegate = microbit
        connectionView.dataSource = microbit
        view.addSubview(connectionView)
        let margins = view.layoutMarginsGuide
        connectionView.topAnchor.constraint(equalTo: margins.topAnchor, constant: 0.0).isActive = true
        connectionView.rightAnchor.constraint(equalTo: margins.rightAnchor,constant: 0.0).isActive = true
        connectionView.leftAnchor.constraint(equalTo: margins.rightAnchor,constant: -300.0).isActive = true
        connectionView.widthAnchor.constraint(equalToConstant: 300.0).isActive = true
    }
}

