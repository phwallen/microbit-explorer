//
//  MicrobitCPUViews.swift
//  
//
//  Created by Peter Wallen on 15/04/2018.
//  Copyright © 2018 Peter Wallen. All rights reserved.
//

import UIKit
protocol MicrobitCPUViewsDelegate {
    func controlButtonPressed(_ key:String)
    func execute(instructionBuffer:String)
    func store(storageBuffer:String)
}
class Layout {
    enum pinType{
        case left
        case right
        case top
        case bottom
        case both
    }
    class func manager(_ uiObject:UIView,margins:UILayoutGuide,left:CGFloat,right:CGFloat,top:CGFloat,bottom:CGFloat,pinH:pinType,pinV:pinType) {
        switch (pinH) {
        case .left :
            uiObject.leadingAnchor.constraint(equalTo: margins.leadingAnchor, constant: left).isActive = true
            uiObject.trailingAnchor.constraint(equalTo: margins.leadingAnchor,constant: right).isActive = true
        case .right :
            uiObject.leadingAnchor.constraint(equalTo: margins.trailingAnchor, constant: left).isActive = true
            uiObject.trailingAnchor.constraint(equalTo: margins.trailingAnchor,constant: right).isActive = true
        case .both :
            uiObject.leadingAnchor.constraint(equalTo: margins.leadingAnchor, constant: left).isActive = true
            uiObject.trailingAnchor.constraint(equalTo: margins.trailingAnchor,constant: right).isActive = true
        default :
            break
        }
        switch (pinV) {
        case .top :
            uiObject.topAnchor.constraint(equalTo: margins.topAnchor, constant: top).isActive = true
            uiObject.bottomAnchor.constraint(equalTo: margins.topAnchor,constant: bottom).isActive = true
        case .bottom :
            uiObject.topAnchor.constraint(equalTo: margins.bottomAnchor, constant: top).isActive = true
            uiObject.bottomAnchor.constraint(equalTo: margins.bottomAnchor,constant: bottom).isActive = true
        case .both :
            uiObject.topAnchor.constraint(equalTo: margins.topAnchor, constant: top).isActive = true
            uiObject.bottomAnchor.constraint(equalTo: margins.bottomAnchor,constant: bottom).isActive = true
        default :
            break
        }
    }
}
class KeyPadView {
    let keyboardSelectControl = UISegmentedControl(items:["Hex Keypad","Binary Keypad"])
    var keyButtonArray = [UIButton]()
    let instructionLabel = UILabel()
    let messageLabel = UILabel()
    let storeButton = UIButton(type:.system)
    var delegate:MicrobitCPUViewsDelegate?
    var instruction:UInt16 = 0
    var hexKeypadSelected = true
    let binaryKeyTitles = ["15","14","13","12","Clear","11","10","9","8"," ","7","6","5","4","","3","2","1","0","Execute"]
    let hexKeyTitles = ["0","1","2","3","Clear","4","5","6","7","All Clear","8","9","A","B","Space","C","D","E","F","Execute"]
    
    var vStackView:UIStackView
    var charactersEntered = 0
    let MAX_CHARACTERS = 32
    
    init(_ view:UIView) {
        vStackView = UIStackView()
        vStackView.axis = .vertical
        vStackView.distribution = .fillEqually
        vStackView.spacing = 5
        vStackView.translatesAutoresizingMaskIntoConstraints = false
        keyboardSelectControl.selectedSegmentIndex = 0
        keyboardSelectControl.translatesAutoresizingMaskIntoConstraints = false
        keyboardSelectControl.addTarget(self,action: #selector(KeyPadView.segmentedControlAction),for: .primaryActionTriggered)
        instructionLabel.translatesAutoresizingMaskIntoConstraints = false
        instructionLabel.backgroundColor = .gray
        messageLabel.backgroundColor = .black
        messageLabel.translatesAutoresizingMaskIntoConstraints = false
        messageLabel.textColor = .white
        storeButton.setTitle("Store", for: .normal)
        storeButton.backgroundColor = .darkGray
        storeButton.translatesAutoresizingMaskIntoConstraints = false
        storeButton.setTitleColor(.white, for: .normal)
        storeButton.titleLabel?.font = UIFont(name: "Helvetica", size: 12)
        storeButton.addTarget(self,action: #selector(KeyPadView.keyButtonAction),for: .primaryActionTriggered)
        
        vStackView.addArrangedSubview(keyboardSelectControl)
        vStackView.addArrangedSubview(instructionLabel)
        let hStackView = UIStackView()
        hStackView.axis = .horizontal
        hStackView.distribution = .equalSpacing
        hStackView.spacing = 5
        hStackView.translatesAutoresizingMaskIntoConstraints = false
        hStackView.addArrangedSubview(messageLabel)
        hStackView.addArrangedSubview(storeButton)
        
        vStackView.addArrangedSubview(hStackView)
        for row in 0 ... 3 {
            let hStackView = UIStackView()
            hStackView.axis = .horizontal
            hStackView.distribution = .fillEqually
            hStackView.spacing = 5
            hStackView.translatesAutoresizingMaskIntoConstraints = false
            for col in 0 ... 4 {
                let keyButton = UIButton(type:.system)
                keyButton.translatesAutoresizingMaskIntoConstraints = false
                keyButton.tag = col * 4 + row
                if col == 4 {
                    keyButton.backgroundColor = .blue
                    keyButton.titleLabel?.font = UIFont(name: "Helvetica", size: 12)
                    if row == 3 {
                        keyButton.backgroundColor = UIColor.darkGray
                    }
                } else {
                    keyButton.backgroundColor = .gray
                }
                keyButton.setTitleColor(.white, for: .normal)
                keyButton.addTarget(self,action: #selector(KeyPadView.keyButtonAction),for: .primaryActionTriggered)
                keyButtonArray.append(keyButton)
                hStackView.addArrangedSubview(keyButton)
            }
            vStackView.addArrangedSubview(hStackView)
        }
        keyButtonArray[0].widthAnchor.constraint(equalTo: storeButton.widthAnchor).isActive = true
        messageLabel.widthAnchor.constraint(equalTo: storeButton.widthAnchor, multiplier: 4.0).isActive=true
        view.addSubview(vStackView)
        let margins = view.layoutMarginsGuide
        Layout.manager(vStackView,margins:margins,left:-400,right:-10,top:100,bottom: 500,pinH:.right,pinV:.top)
        hexKeypad()
    }
    func changeLayout(_ view:UIView,width:CGFloat) {
        //let margins = view.layoutMarginsGuide
        if width > 800 {
            //Layout.manager(vStackView,margins:margins,left:-400,right:-10,top:200,bottom: 600,pinH:.right,pinV:.top)
            vStackView.isHidden = false
        } else {
            vStackView.isHidden = true
        }
    }
    func hexKeypad() {
        for row in 0 ... 3 {
            for col in 0 ... 4 {
                keyButtonArray[col * 4 + row].setTitle(hexKeyTitles[col * 4 + row], for: .normal)
            }
        }
    }
    func binaryKeypad() {
        for row in 0 ... 3 {
            for col in 0 ... 4 {
                keyButtonArray[col * 4 + row].setTitle(binaryKeyTitles[col * 4 + row], for: .normal)
            }
        }
    }
    @objc func segmentedControlAction(sender:UISegmentedControl) {
        switch sender.selectedSegmentIndex {
        case 0 :
            hexKeypad()
            hexKeypadSelected = true
            //clearBinary()
            for button in keyButtonArray {
                if button.titleLabel?.text != "Execute" && button.titleLabel?.text != "Clear" && button.titleLabel?.text != " "  && button.titleLabel?.text != "All Clear" && button.titleLabel?.text != "Space" {
                    button.backgroundColor = .gray
                }
            }
            messageLabel.text = ""
            //instructionLabel.text = ""
            charactersEntered = 0
        case 1 :
            binaryKeypad()
            hexKeypadSelected = false
            messageLabel.text = ""
            clearBinary()
        default :
            print("Invalid keypad selected")
        }
    }
    @objc func keyButtonAction(sender:UIButton) {
        messageLabel.text = ""
        switch sender.titleLabel?.text {
        case "Execute" :
            let trimmedInstruction = instructionLabel.text?.components(separatedBy: .whitespaces).joined()
            if ((trimmedInstruction?.count)! % 4) != 0 {
                messageLabel.text = "Incomplete instruction"
            } else {
                delegate?.execute(instructionBuffer: trimmedInstruction!)
            }
        case "Clear" :
            if hexKeypadSelected {
                clearHex()
            } else {
                clearBinary()
            }
        case "All Clear" :
            instructionLabel.text = ""
            charactersEntered = 0
        case "Space" :
            instructionLabel.text = instructionLabel.text! + " "
        case "Store" :
            if let instructionBuffer = instructionLabel.text {
                delegate?.store(storageBuffer: instructionBuffer)
            }
        default :
            if hexKeypadSelected {
                hexKey(sender)
            } else {
                binaryKey(sender)
            }
        }
    }
    func binaryKey(_ sender:UIButton) {
        let key = Int((sender.titleLabel?.text!)!)
        if let key = key {
            let mask:UInt16 = 1 << key
            instruction = instruction ^ mask
            instructionLabel.text = String(format: "%04X", instruction)
            if instruction & mask == mask {
                sender.backgroundColor = .red
            } else {
                sender.backgroundColor = .gray
            }
        }
    }
    
    func hexKey(_ sender:UIButton) {
        let key = sender.titleLabel?.text
        let textCurrentlyInDisplay = instructionLabel.text
        if charactersEntered < MAX_CHARACTERS {
            if textCurrentlyInDisplay == nil {
                instructionLabel.text = key!
            } else {
                instructionLabel.text = textCurrentlyInDisplay! + key!
            }
            charactersEntered += 1
        } else {
            messageLabel.text = "Maximum number of characters entered"
        }
    }
    func clearBinary() {
        for button in keyButtonArray {
            if button.titleLabel?.text != "Execute" && button.titleLabel?.text != "Clear" && button.titleLabel?.text != " "  && button.titleLabel?.text != "All Clear" && button.titleLabel?.text != "Space" {
                button.backgroundColor = .gray
            }
        }
        instruction = 0
        instructionLabel.text = String(format: "%04X", instruction)
    }
    func clearHex() {
        if ((instructionLabel.text?.count)! > 0) {
            let subString = instructionLabel.text?.dropLast()
            instructionLabel.text = String(subString!)
            messageLabel.text = ""
            if instructionLabel.text?.last != " " {
                charactersEntered -= 1
            }
        }
    }
}

class ControlButtonsView{
    var controlButtonArray = [UIButton]()
    var delegate:MicrobitCPUViewsDelegate?
    init(_ view:UIView) {
        let keyTitles = ["Connect","Reset","Clear"]
        let hStackView = UIStackView()
        hStackView.axis = .horizontal
        hStackView.distribution = .fillEqually
        hStackView.spacing = 5
        hStackView.translatesAutoresizingMaskIntoConstraints = false
        for button in 0 ... 2 {
            let keyButton = UIButton(type:.system)
            keyButton.translatesAutoresizingMaskIntoConstraints = false
            keyButton.tag = button
            keyButton.backgroundColor = .lightGray
            keyButton.setTitleColor(.white, for: .normal)
            keyButton.setTitle(keyTitles[keyButton.tag], for: .normal)
            keyButton.addTarget(self,action: #selector(ControlButtonsView.buttonAction),for: .primaryActionTriggered)
            controlButtonArray.append(keyButton)
            hStackView.addArrangedSubview(keyButton)
        }
        view.addSubview(hStackView)
        let margins = view.layoutMarginsGuide
        Layout.manager(hStackView,margins:margins,left:10,right:470,top:10,bottom: 60,pinH:.left,pinV:.top)
    }
    @objc func buttonAction(sender:UIButton) {
        delegate?.controlButtonPressed((sender.titleLabel?.text)!)
    }
}
class RegisterView{
    var registerViewArray = [UILabel]()
    let psrV = UILabel()
    let psrC = UILabel()
    let psrZ = UILabel()
    let psrN = UILabel()
    init(_ view:UIView) {
        let psrStackView = UIStackView()
        psrStackView.axis = .horizontal
        psrStackView.distribution = .fill
        psrStackView.spacing = 5
        psrStackView.translatesAutoresizingMaskIntoConstraints = false
        for field in 1 ... 5 {
            switch field {
            case 1:
                let label = UILabel()
                label.text = "Program Status Register:"
                label.textAlignment = .right
                label.adjustsFontSizeToFitWidth = true
                psrStackView.addArrangedSubview(label)
            case 2:
                psrN.text = "N"
                psrN.textColor = .lightGray
                psrStackView.addArrangedSubview(psrN)
            case 3:
                psrZ.text = "Z"
                psrZ.textColor = .lightGray
                psrStackView.addArrangedSubview(psrZ)
            case 4:
                psrC.text = "C"
                psrC.textColor = .lightGray
                psrStackView.addArrangedSubview(psrC)
            case 5:
                psrV.text = "V"
                psrV.textColor = .lightGray
                psrStackView.addArrangedSubview(psrV)
            default:
                print("Invalid PSR field")
            }
        }
        let vStackView = UIStackView()
        vStackView.axis = .vertical
        vStackView.distribution = .fill
        vStackView.spacing = 5
        vStackView.translatesAutoresizingMaskIntoConstraints = false
        
        for row in 0 ... 7 {
            let hStackView = UIStackView()
            hStackView.axis = .horizontal
            hStackView.distribution = .fill
            //hStackView.alignment = .fill
            hStackView.spacing = 5
            hStackView.translatesAutoresizingMaskIntoConstraints = false
            for col in 0 ... 3 {
                let label = UILabel()
                label.textAlignment = .right
                label.text = "0"
                if col == 0 {
                    label.text = String(row)
                    label.textAlignment = .right
                    label.widthAnchor.constraint(equalToConstant: 20.0).isActive = true
                }
                if col == 1 {
                    label.text = "00000000"
                    label.textAlignment = .center
                    label.backgroundColor = .lightGray
                    label.widthAnchor.constraint(equalToConstant: 120.0).isActive = true
                    label.font = label.font.withSize(20)
                }
                if col == 2 {
                    label.adjustsFontSizeToFitWidth = true
                    //label.widthAnchor.constraint(equalToConstant: 100.0).isActive = true
                }
                
                if col == 3 {
                    label.textColor = .white
                    label.text = " "
                    label.widthAnchor.constraint(equalToConstant: 20.0).isActive = true
                }
 
                registerViewArray.append(label)
                hStackView.addArrangedSubview(label)
            }
            vStackView.addArrangedSubview(hStackView)
            vStackView.addArrangedSubview(psrStackView)
            view.addSubview(vStackView)
            let margins = view.layoutMarginsGuide
            Layout.manager(vStackView,margins:margins,left:0,right:300,top:40,bottom: 260,pinH:.left,pinV:.top)
        }
    }
    func set(register:Int,value:Int32) {
        if register > 7 || register < 0 {return}
        let numberFormatter = NumberFormatter()
        numberFormatter.numberStyle = NumberFormatter.Style.decimal
        registerViewArray[register * 4 + 2].text = numberFormatter.string(from: NSNumber(value:value))
        registerViewArray[register * 4 + 1].text = String(format:"%08X",value)
        if value >= 0 {
            if let displayCharacter = UnicodeScalar(Int(value)) {
                registerViewArray[register * 4 + 3].text = String(displayCharacter)
            } else {
                registerViewArray[register * 4 + 3].text = " "
            }
        } else {
            registerViewArray[register * 4 + 3].text = " "
        }
    }
    func setPSR(value:UInt32) {
        var psr:[Bool] = Array(repeating:false,count:4)
        psr[0] = (value & 0x10000000 != 0)
        psr[1] = (value & 0x20000000 != 0)
        psr[2] = (value & 0x40000000 != 0)
        psr[3] = (value & 0x80000000 != 0)
        if psr[0] {psrV.textColor = .black} else {psrV.textColor = .lightGray}
        if psr[1] {psrC.textColor = .black} else {psrC.textColor = .lightGray}
        if psr[2] {psrZ.textColor = .black} else {psrZ.textColor = .lightGray}
        if psr[3] {psrN.textColor = .black} else {psrN.textColor = .lightGray}
    }
}
class MemoryView {
    var memoryViewArray = [UILabel]()
    init(_ view:UIView) {
        let hStackView = UIStackView()
        hStackView.axis = .horizontal
        hStackView.distribution = .fillEqually
        hStackView.spacing = 5
        hStackView.translatesAutoresizingMaskIntoConstraints = false
        for col in 0 ... 3 {
            let cell = UILabel()
            cell.tag = col
            cell.text = "00000000"
            cell.translatesAutoresizingMaskIntoConstraints = false
            cell.backgroundColor = .lightGray
            memoryViewArray.append(cell)
            hStackView.addArrangedSubview(cell)
        }
        view.addSubview(hStackView)
        let margins = view.layoutMarginsGuide
        Layout.manager(hStackView,margins:margins,left:10,right:-10,top:20,bottom: -10,pinH:.both,pinV:.both)
    }
    func update(memory:[Int32]) {
        for cell in 0 ... 3 {
            memoryViewArray[cell].text = String(format:"%08X",memory[cell].bigEndian)
        }
    }
}
class ProcessorView {
    var base = UIView(frame: CGRect(x: 50, y: 80, width: 460, height: 600))
    let alu = UIView(frame: CGRect(x: 10, y: 10, width: 160, height: 100))
    let decoder = UIView(frame:CGRect(x: 240, y: 10, width: 220, height: 100))
    let registers = UIView(frame: CGRect(x: 10, y: 170, width: 450, height: 350))
    let memory = UIView(frame: CGRect(x:10,y:450,width:450,height:70))
    let arrow1 = UILabel(frame: CGRect(x: 180, y: 50, width: 50, height: 20))
    let arrow2 = UILabel(frame: CGRect(x: 80, y: 125, width: 50, height: 30))
    let aluLabel = UILabel(frame: CGRect(x: 0, y: 0, width: 150, height: 80))
    let decoderLabel = UILabel(frame: CGRect(x: 0, y: 0, width: 150, height: 20))
    let registerLabel = UILabel(frame: CGRect(x: 0, y: 20, width: 450, height: 20))
    let memoryLabel = UILabel(frame:CGRect(x: 0, y: 0, width: 100, height: 20))
    let instructionLabel = UILabel(frame: CGRect(x: 0, y: 20, width: 150, height: 50))
    let messageLabel = UILabel(frame: CGRect(x: 200, y: 40, width: 300, height: 80))
    let aluColour = UIColor(displayP3Red: 218 / 255, green: 65 / 255, blue: 56 / 255, alpha: 1.0)
    let decoderColour = UIColor(displayP3Red: 218 / 255, green: 65 / 255, blue: 56 / 255, alpha: 1.0)
    let registersColour = UIColor(displayP3Red: 218 / 255, green: 65 / 255, blue: 56 / 255, alpha: 1.0)
    var registerView:RegisterView?
    var memoryView:MemoryView?
    
    init (_ view:UIView) {
        base.backgroundColor = .gray
        base.translatesAutoresizingMaskIntoConstraints = false
        decoder.backgroundColor = decoderColour
        registers.backgroundColor = registersColour
        memory.backgroundColor = .blue
        alu.backgroundColor = aluColour
        registerView = RegisterView(registers)
        memoryView = MemoryView(memory)
        base.addSubview(decoder)
        base.addSubview(registers)
        base.addSubview(alu)
        base.addSubview(memory)
        addArrow(arrow1, to: base, text: "⬅️")
        addArrow(arrow2, to: base, text: "↕️")
        addLabel(aluLabel, to: alu, text: "Arithmetic\nLogic\nUnit")
        addLabel(decoderLabel, to: decoder, text: "Decoder")
        addLabel(instructionLabel, to: decoder, text: "")
        addLabel(messageLabel, to: base, text: "")
        addLabel(registerLabel, to: registers, text: "General Registers")
        addLabel(memoryLabel, to: memory, text: "Memory")
        view.addSubview(base)
        let margins = view.layoutMarginsGuide
        Layout.manager(base,margins:margins,left:10,right:500,top:50,bottom: -10,pinH:.left,pinV:.both)
    }
    func addArrow(_ label:UILabel, to baseView:UIView,text:String) {
        label.numberOfLines = 3
        label.text = text
        label.font = label.font.withSize(50)
        label.textAlignment = .center
        baseView.addSubview(label)
    }
    func addLabel(_ label:UILabel, to baseView:UIView,text:String) {
        //label.backgroundColor = .lightGray
        label.numberOfLines = 3
        label.text = text
        label.textColor = .white
        label.font = label.font.withSize(20)
        label.adjustsFontSizeToFitWidth = true
        label.textAlignment = .center
        baseView.addSubview(label)
    }
    func instruction(_ instruction:String) {
        instructionLabel.text = instruction
    }
    func message(_ message:String) {
        messageLabel.text = message
    }
}
