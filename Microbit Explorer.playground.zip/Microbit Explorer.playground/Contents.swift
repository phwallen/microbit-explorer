/*:
 # Micro:bit Explorer Playground
 This playground helps explore how the Micro:bit application processor functions, helping students gain an understanding of some principal concepts of computer science.
 
 For information on using this playground see [Micro:bit Explorer](https://phwallen.github.io/microbit-explorer/)
*/
import UIKit
import PlaygroundSupport
let microbitCPU = MicrobitCPU()
let microbitCPUViewController = MicrobitCPUViewController()
microbitCPUViewController.microbitCPU = microbitCPU
PlaygroundPage.current.liveView = microbitCPUViewController
